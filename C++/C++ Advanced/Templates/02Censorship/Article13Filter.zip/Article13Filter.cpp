
#include "Article13Filter.h"


Article13Filter::Article13Filter(std::set<std::string> copyrighted) : copyrighted(copyrighted) {};

bool Article13Filter::blockIfCopyrighted(std::string s) {
	
	if (isCopyrighted(s)) {
		Article13Filter::blocked.push_back(s);
		return true;
	}
	else 
		return false;
}

bool Article13Filter::isCopyrighted(std::string s) {
	bool isIn = false;
	std::set<std::string>::iterator it = std::find(copyrighted.begin(), copyrighted.end(), s);
	if (it != copyrighted.end()) {
		isIn = true;
	}
	else 
		isIn = false;

	return isIn;
}

std::vector<std::string> Article13Filter::getBlocked() {
	return Article13Filter::blocked;
}