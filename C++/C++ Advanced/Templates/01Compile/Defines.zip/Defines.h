#ifndef  DEFINES_H
#define DONT_COMPILE_THIS

#define STANDARD_TEMPLATE_LIBRARY namespace std
#include <iostream>
#include <string>

#define DEFINES_H
#endif // ! DEFINES_H
