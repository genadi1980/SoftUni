#ifndef  ECHO_H
#define ECHO_H

#include <string>
#include <iostream>

extern bool echoOn;

void echo(const std::string & message);

#endif // ! ECHO_H
