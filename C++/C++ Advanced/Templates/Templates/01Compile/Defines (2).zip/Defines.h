#ifndef  DEFINES_H
#define DEFINES_H

#define DONT_COMPILE_THIS

#include <iostream>
#include <string>

#define STANDARD_TEMPLATE_LIBRARY namespace std;

#endif // ! DEFINES_H
