#ifndef VECTOR_COMPARATOR_H

#include "Vector.h"


#define VECTOR_COMPARATOR_H

#endif // !VECTOR_COMPARATOR_H