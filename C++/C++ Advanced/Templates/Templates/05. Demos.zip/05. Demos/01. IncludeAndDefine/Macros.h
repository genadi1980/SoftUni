#define PI 3.14

#include<iostream>

#define SHOW(something) std::cout << something << std::endl;
