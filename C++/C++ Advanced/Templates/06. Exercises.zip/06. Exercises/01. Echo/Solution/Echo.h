#ifndef ECHO_H
#define ECHO_H

#include <iostream>
#include <string>

extern bool echoOn;

void echo(std::string message);

#endif // !ECHO_H

