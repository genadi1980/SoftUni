#ifndef  ECHO_H

#include <iostream>
#include <string>

extern bool echoOn;

void echo(std::string message);

#define ECHO_H
#endif // ! ECHO_H
