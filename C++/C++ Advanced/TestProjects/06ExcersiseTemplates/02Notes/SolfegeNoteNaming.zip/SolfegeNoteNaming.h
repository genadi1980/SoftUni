#ifndef SOLFEGENOTENAMING_H

#include <string>
#include "NoteName.h"

struct SolfegeNoteNaming {
	NoteName operator()(const std::string& noteText) const {
		if
	}
};
#define SOLFEGENOTENAMING_H
#endif // !SOLFEGENOTENAMING_H
