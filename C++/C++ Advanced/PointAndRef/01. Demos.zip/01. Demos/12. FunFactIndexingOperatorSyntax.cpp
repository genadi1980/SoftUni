#include <iostream>

int main() {
	using namespace std;

	int arr[3]{ 13, 42, 69 };

	cout << 1[arr] << endl;

	return 0;
}
