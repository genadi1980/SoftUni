#ifndef COORDINATE_SYSTEM_CENTER_H
#define COORDINATE_SYSTEM_CENTER_H

#include "Shape.h"

class CoordinateSystemCenter : public Shape {};

#endif // !COORDINATE_SYSTEM_CENTER_H

