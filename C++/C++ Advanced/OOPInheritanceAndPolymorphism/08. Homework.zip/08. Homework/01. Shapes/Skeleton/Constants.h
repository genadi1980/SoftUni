#ifndef CONSTANTS_H
#define CONSTANTS_H

extern double PI;

#endif // !CONSTANTS_H
