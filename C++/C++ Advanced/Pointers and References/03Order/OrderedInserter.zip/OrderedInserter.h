#pragma once
#ifndef ORDERINSERVER_H

#include "Company.h"
#include <vector>

class OrderedInserter
{
	
	std::vector< const Company *, std::allocator <const Company * >> & companies;

public:
	OrderedInserter(std::vector< const Company *, 
		std::allocator <const Company * >> & companies) 
		: companies(companies) {}

	void insert ( const Company* c)
	{
		companies.push_back(c);
	}

};

#define ORDERINSERVER_H
#endif // !ORDERINSERVER_H

