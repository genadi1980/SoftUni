#pragma once
#ifndef MIN_BY_H

#include <string>
#include <vector>

std::string minBy(std::vector<std::string> values, bool(*func)(const std::string& a, const std::string& b)) {
	
	
	std::string max = values[0];;
	for (int i = 0; i < values.size(); ++i) {
		
		if (func(values[i],max))
		{			
			if (max == values[i]) {
				max;
				break;
			}

			max = values[i];

		}
		
		

	}
	return max;
}
#define MIN_BY_H
#endif // !MIN_BY_H