
#include "Company.h"
#include "Register.h"
#include <vector>


std::vector<Company> companies;
Register::Register(size_t numCompanies) 
					: numAdded(numCompanies)
					, companiesArray(new Company[numAdded]) {}

void Register::add(const Company & c) {
	
	for (size_t i = 0; i < numAdded; ++i) {
		companiesArray[i] = c;
	}
	companies.push_back(c);
}


Company Register::get(int companyId) const {
	Company c;
	std::vector<Company>::iterator it;
	for (it = companies.begin(); it != companies.end(); ++it) {
		if (companyId == it->getId()) {
			return *it;
		}
	}
	return c;
}


Register::~Register() {
	delete[] this->companiesArray;
}