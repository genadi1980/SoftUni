#ifndef DEFINES_H_
#define DEFINES_H_

enum ErrorCode
{
    PARSE_SUCCESS = 0,
    PARSE_FAILURE = 1,
    PARSE_EMPTY   = 2
};



#endif /* DEFINES_H_ */
